import pygame

from primiengine import Log, Assets, Render, Actors, Actor


def main():

    pygame.init()
    screen = pygame.display.set_mode((800, 600))

    # start each subsystem's background thread now that a screen exists
    Render.init(screen)
    Actors.init()

    log = Log.get("main")
    log.info("Engine starting")

    # kick off a background load, don't block startup on it
    Assets.queue("player", "assets/player.png")

    player_sprite = None
    clock = pygame.time.Clock()
    running = True

    while running:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # finalize anything the loader thread finished this frame
        Assets.update()

        if player_sprite is None and Assets.ready("player"):
            from primiengine.sprite import Sprite
            player_sprite = Sprite(Assets.get("player"))
            Render.add(player_sprite, layer=1)
            log.success("Player sprite ready")

        # Render's own thread is already drawing sprites onto `screen`;
        # this just flips it, once per frame, from the main thread
        Render.present()

        clock.tick(60)

    log.info("Shutting down")
    Actors.close()
    Render.close()
    Log.close()


if __name__ == "__main__":
    main()
